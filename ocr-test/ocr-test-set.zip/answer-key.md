# OCR benchmark answer key

Qty is in units (pieces). Items marked *not in catalog* should come out unmatched.


## D01 · Clean tax invoice (phone photo) (D01.jpg)
AL NOOR FOODSTUFF TRADING · English  
Tests: Baseline: barcodes, clear table, good light  
Damage: slight perspective, soft lighting gradient, mild blur

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Basmati Rice 5kg | 10 |  |
| 2 | Sunflower Oil 1.5L | 12 |  |
| 3 | White Sugar 2kg | 15 |  |
| 4 | Chickpeas Canned 400g | 24 |  |
| 5 | Green Tea 100 Bags | 6 |  |
| 6 | Tomato Paste 135g | 48 |  |

## D02 · Faded thermal receipt (D02.jpg)
GULF FRESH SUPPLIES · English  
Tests: Abbreviated names (PST, CHKN, JCE, WHT, LF), 'x24' quantities, monospace, no barcodes  
Damage: uneven thermal fade, low contrast, slight curl and tilt

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Tomato Paste 135g | 24 |  |
| 2 | Instant Noodles Chicken 75g | 40 |  |
| 3 | Orange Juice 200ml | 30 |  |
| 4 | White Sugar 2kg | 6 |  |
| 5 | Green Tea 100 Bags | 3 |  |
| 6 | Laban Low Fat 1L | 12 |  |

## D03 · Bilingual delivery note (cartons) (D03.jpg)
RAWABI DISTRIBUTION · English + Arabic  
Tests: Supplier codes (RW-114 is already saved), cartons x pieces per carton, one item not in catalog  
Damage: scanned at a 4° skew, grey paper, sensor noise

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Fresh Milk Full Fat 1L | 48 | saved supplier code |
| 2 | Laban Low Fat 1L | 36 |  |
| 3 | Arabic Bread Large 6pcs | 20 |  |
| 4 | Mineral Water 330ml 20 Pack | 5 |  |
| 5 | — not in catalog — | 20 | not in catalog |

## D04 · Arabic-only invoice (D04.jpg)
مؤسسة الواحة للمواد الغذائية (AL WAHA) · Arabic  
Tests: Arabic product names only, Eastern Arabic digits (٠١٢٣), right-to-left table  
Damage: out of focus, low resolution, JPEG compression

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Basmati Rice 5kg | 8 |  |
| 2 | Sunflower Oil 1.5L | 10 |  |
| 3 | Dates Sukkari 1kg | 12 |  |
| 4 | Orange Juice 200ml | 48 |  |
| 5 | Chickpeas Canned 400g | 24 |  |

## D05 · Carbon-copy purchase order (D05.jpg)
SAHARA WHOLESALE EST. · English  
Tests: Typewriter/dot-matrix font, carbon ink, one misprinted barcode (must fall back to name)  
Damage: purple carbon ink bleed, uneven pressure, paper texture, low contrast

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Basmati Rice 5kg | 20 |  |
| 2 | Dates Sukkari 1kg | 10 | barcode misprinted (…0071 instead of …0017) |
| 3 | Instant Noodles Chicken 75g | 120 |  |
| 4 | Orange Juice 200ml | 72 |  |
| 5 | Mineral Water 330ml 20 Pack | 10 |  |

## D06 · Dense 12-line wholesale invoice (D06.jpg)
AL JAZEERA WHOLESALE · English  
Tests: 12 lines in a small font, mixed barcode / no barcode, reordered names, 2 items not in catalog  
Damage: low resolution, heavy JPEG artefacts

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Basmati Rice 5kg | 5 |  |
| 2 | White Sugar 2kg | 10 |  |
| 3 | Tomato Paste 135g | 96 |  |
| 4 | Fresh Milk Full Fat 1L | 24 |  |
| 5 | Instant Noodles Chicken 75g | 60 |  |
| 6 | Arabic Bread Large 6pcs | 10 |  |
| 7 | — not in catalog — | 48 | not in catalog |
| 8 | Chickpeas Canned 400g | 36 |  |
| 9 | Green Tea 100 Bags | 12 |  |
| 10 | — not in catalog — | 12 | not in catalog |
| 11 | Mineral Water 330ml 20 Pack | 15 |  |
| 12 | Orange Juice 200ml | 60 |  |

## D07 · Crumpled invoice photo (D07.jpg)
DESERT ROSE TRADING · English  
Tests: Quantities in dozens (DZN) and cartons, serif font; expected qty is in units  
Damage: crumpled paper, creases and shadows, photographed at an angle on a table

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Green Tea 100 Bags | 24 | dozens → units |
| 2 | Tomato Paste 135g | 48 | dozens → units |
| 3 | Fresh Milk Full Fat 1L | 24 | cartons of 12 → units |
| 4 | Sunflower Oil 1.5L | 6 |  |
| 5 | Dates Sukkari 1kg | 5 |  |

## D08 · Stamped bilingual invoice (D08.jpg)
TAMR AL MADINA DATES & FOODS · English + Arabic  
Tests: Company stamp and signature over the table, COPY watermark, Arabic + English on the same line  
Damage: mild phone photo, slight blur

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Dates Sukkari 1kg | 30 |  |
| 2 | Green Tea 100 Bags | 12 |  |
| 3 | Laban Low Fat 1L | 24 |  |
| 4 | Sunflower Oil 1.5L | 6 |  |
| 5 | — not in catalog — | 4 | not in catalog |

## D09 · Delivery slip in low light (D09.jpg)
AL RAYYAN FOODS · English  
Tests: Quantity first ('12 x Oil Sunflower 1.5 Ltr'), word order reversed, spaced units (5 KG, 400 gm), no barcodes or prices  
Damage: dark room, yellow cast, heavy noise, motion blur, vignette

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Sunflower Oil 1.5L | 12 |  |
| 2 | Basmati Rice 5kg | 6 |  |
| 3 | Arabic Bread Large 6pcs | 20 |  |
| 4 | Chickpeas Canned 400g | 36 |  |
| 5 | Orange Juice 200ml | 24 |  |
| 6 | White Sugar 2kg | 10 |  |

## D10 · Faxed order with a correction (D10.png)
NAJD FOOD SUPPLY CO. · English + Arabic  
Tests: Fax/photocopy look, a struck-out quantity corrected by hand (25 → 20), supplier codes  
Damage: black-and-white fax, speckle noise, 6° skew, dark copier edges

| # | Expected product | Qty | Note |
|---|---|---|---|
| 1 | Basmati Rice 5kg | 15 |  |
| 2 | White Sugar 2kg | 20 | handwritten correction 25 → 20 |
| 3 | Instant Noodles Chicken 75g | 48 |  |
| 4 | Mineral Water 330ml 20 Pack | 8 |  |
| 5 | Fresh Milk Full Fat 1L | 24 |  |
